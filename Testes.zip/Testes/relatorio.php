<?php
session_start();
include_once("conexao.php");

if(!isset($_SESSION['id'])){
    header("Location: index.php");
    exit();
}

$usuario_id = $_SESSION['id'];
$tipo_usuario = $_SESSION['tipo'];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Relatório de Vendas</title>
</head>
<body>
<fieldset>
<h1>Relatório de Vendas</h1>

<?php
if($tipo_usuario == 'admin'){
    $sql = "SELECT comp.id as compra_id, cli.nome as cliente, cli.email, cli.telefone,
            cli.endereco, cli.bairro, cli.cidade, cli.estado, cli.pais,
            p.nome as produto, comp.quantidade, comp.subtotal, comp.data_compra
            FROM compras comp
            INNER JOIN clientes cli ON comp.cliente_id = cli.id
            INNER JOIN produtos p ON comp.produto_id = p.id
            ORDER BY comp.data_compra DESC";
} else {
    $sql = "SELECT comp.id as compra_id, cli.nome as cliente, cli.email, cli.telefone,
            cli.endereco, cli.bairro, cli.cidade, cli.estado, cli.pais,
            p.nome as produto, comp.quantidade, comp.subtotal, comp.data_compra
            FROM compras comp
            INNER JOIN clientes cli ON comp.cliente_id = cli.id
            INNER JOIN produtos p ON comp.produto_id = p.id
            WHERE cli.id = $usuario_id
            ORDER BY comp.data_compra DESC";
}

$result = $conn->query($sql);

if($result->num_rows>0){
    echo "<table border='1' cellpadding='5'>
    <tr>
        <th>Cliente</th>
        <th>Email</th>
        <th>Telefone</th>
        <th>Endereço</th>
        <th>Produto</th>
        <th>Quantidade</th>
        <th>Subtotal</th>
        <th>Data/Hora</th>
    </tr>";

    while($row = $result->fetch_assoc()){
        echo "<tr>
            <td>".$row['cliente']."</td>
            <td>".$row['email']."</td>
            <td>".$row['telefone']."</td>
            <td>".$row['endereco'].", ".$row['bairro'].", ".$row['cidade']." - ".$row['estado'].", ".$row['pais']."</td>
            <td>".$row['produto']."</td>
            <td>".$row['quantidade']."</td>
            <td>R$ ".number_format($row['subtotal'],2,",",".")."</td>
            <td>".$row['data_compra']."</td>
        </tr>";
    }
    echo "</table>";
}else{
    echo "<p>Nenhuma compra registrada.</p>";
}

echo "<br><button onclick=\"window.location.href='produtos.php'\">Voltar aos Produtos</button> ";
echo "<button onclick=\"window.location.href='logout.php'\">Sair</button>";
?>
</fieldset>
</body>
</html>