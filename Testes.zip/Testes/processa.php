<?php
session_start();
include_once("conexao.php");

$nome     = $_POST['nome'];
$email    = $_POST['email'];
$sexo     = $_POST['sexo'];
$telefone = $_POST['telefone'];
$endereco = $_POST['endereco'];
$cidade   = $_POST['cidade'];
$estado   = $_POST['estado'];
$bairro   = $_POST['bairro'];
$pais     = $_POST['pais'];
$login    = $_POST['login'];
$senha    = password_hash($_POST['senha'], PASSWORD_DEFAULT); // criptografia
$tipo     = 'cliente'; // padrão cliente

$sql = "INSERT INTO clientes (nome,email,sexo,telefone,endereco,cidade,estado,bairro,pais,login,senha,tipo)
        VALUES ('$nome','$email','$sexo','$telefone','$endereco','$cidade','$estado','$bairro','$pais','$login','$senha','$tipo')";

if(mysqli_query($conn, $sql)){
    $_SESSION['msg'] = "<p style='color:green;'>Usuário cadastrado com sucesso!</p>";
    header("Location: cadastro.php");
} else {
    $_SESSION['msg'] = "<p style='color:red;'>Erro ao cadastrar: ".mysqli_error($conn)."</p>";
    header("Location: cadastro.php");
}
?>