<?php
session_start();
if(!isset($_SESSION['id'])){
    header("Location: index.php");
    exit();
}


?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Produtos</title>
</head>
<body>
<fieldset>
<h1>Lista de Produtos</h1>
<form action="confirmacao.php" method="post">

<p>Arroz 5kg (R$ 25,00)
<input type="number" name="qtd[0]" value="0" min="0">
<input type="hidden" name="nome[0]" value="Arroz 5kg">
<input type="hidden" name="valor[0]" value="25"></p>

<p>Feijão 1kg (R$ 8,00)
<input type="number" name="qtd[1]" value="0" min="0">
<input type="hidden" name="nome[1]" value="Feijão 1kg">
<input type="hidden" name="valor[1]" value="8"></p>

<p>Macarrão 500g (R$ 5,00)
<input type="number" name="qtd[2]" value="0" min="0">
<input type="hidden" name="nome[2]" value="Macarrão 500g">
<input type="hidden" name="valor[2]" value="5"></p>

<p>Leite 1L (R$ 4,50)
<input type="number" name="qtd[3]" value="0" min="0">
<input type="hidden" name="nome[3]" value="Leite 1L">
<input type="hidden" name="valor[3]" value="4.5"></p>

<p>Pão Francês 1kg (R$ 12,00)
<input type="number" name="qtd[4]" value="0" min="0">
<input type="hidden" name="nome[4]" value="Pão Francês 1kg">
<input type="hidden" name="valor[4]" value="12"></p>

<button type="submit">Continuar</button>
<button type="button" onclick="window.location.href='logout.php'">Encerrar</button>

</form>
</fieldset>
</body>
</html>